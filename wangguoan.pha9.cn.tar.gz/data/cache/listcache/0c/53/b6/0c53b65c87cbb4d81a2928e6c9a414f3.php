<?php exit('dedecms');?>
a:2:{s:4:"data";a:1:{s:2:"dd";s:1:"6";}s:7:"timeout";i:1548819195;}