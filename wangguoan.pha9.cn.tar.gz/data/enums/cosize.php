<?php
global $em_cosizes;
$em_cosizes = array();
$em_cosizes['1'] = '50人以下';
$em_cosizes['2'] = '50-200人';
$em_cosizes['3'] = '200-500人';
$em_cosizes['4'] = '500-2000人';
$em_cosizes['5'] = '2000-5000人';
$em_cosizes['6'] = '5000人以上';
?>